
# Firework Effect with Javascript 

Hey, this is a click effect project. Firework Click Effect with Javascript & HTML canvas. When clicked anywhere on the canvas, it renders a number of balls showing a firework effect that looks really cool and unique.




[🔴 Youtube Tutorial Video](https://youtu.be/kvZpMWjnSPg)

[🔵 Live Project URL](https://teenageprogrammer.github.io/Firework-Click-Effect-Javascript/)





## Screenshot

![App Screenshot](https://i.ibb.co/XV2pSdy/Thumbnail.png)


## 🚀 About Me
Teenage Programmer - Developing unique projects and trying to make web development learning easy to freshy users in this field. Fast track your development career with me. Hope you'll love my creativity.


[SUBSCRIBE YOUTUBE](https://www.youtube.com/channel/UCHpW7UyMQf0SXpdO0obb1ig)


![App Screenshot](https://yt3.ggpht.com/oGB27ubPR1zD7eqatjSUZRnMqdr1WAV6g3wC39d-G0hFTIrkzq0FK5_Z9sgAGQsTHEzOOgSw=s88-c-k-c0x00ffffff-no-rj)
